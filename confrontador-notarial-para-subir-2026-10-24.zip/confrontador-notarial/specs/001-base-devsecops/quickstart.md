# Quickstart de validación · F1

Esta guía distingue los checkpoints ejecutados de las etapas pendientes. Las
etapas 1–4 tienen evidencia local abajo; no se afirma CI verde ni F1 completa.

## Checkpoint ejecutado · Etapa 1 (T001–T006)

Revisión local del árbol partiendo de `6c2539e`, con constitución v1.3.0.
`git status --short` confirmó el árbol limpio y
`gh repo view --json visibility --jq .visibility` confirmó `PRIVATE`.
No se activó SonarQube ni se enviaron documentos o historial a servicios externos.

| Alcance de T001 | Saneamiento y resultado |
|---|---|
| 72 archivos versionados: código, tests, documentación, metadatos y rutas | Revisión local de literales, referencias e identificadores, con salida redactada. No se copiaron valores originales a informes ni archivos temporales. |
| Los cinco `test_*.py` | Identificadores, nombres, fragmentos y referencias ficticios; se conservan las 34 aserciones, sus casos y relaciones esperadas. |
| `bench_llm.py`, `verificar.py`, `lexico.py`, `README.md` | Ejemplos, comentarios y referencias saneados; sin cambios en las reglas del verificador ni del léxico. El benchmark no se ejecutó. |
| `revisor_llm.py` | Ruta personal de credenciales sustituida por `.env` junto al módulo; se conserva la prioridad de `GEMINI_API_KEY`. No se leyeron credenciales ni se llamó a modelos. |
| Fixtures | Cero archivos documentales versionados que renombrar. Referencias neutras bajo `tests/fixtures/`: `cliente/dni.png`, `cliente/minuta.docx`, `borrador/observado.docx`, `resultado/correcto.docx` y `ajeno/plantilla.doc`. Su generación queda en T009. |
| `.gitignore` | Exclusiones de expedientes y secretos conservadas; patrón de carpetas con sufijo numérico reparado al separar el comentario. Añadidos fixtures generados, formatos documentales y artefactos locales de calidad. |

Datos de prueba: cuatro DNI distintos de ocho dígitos (`90000001`–`90000004`),
con CUI `90000004-1`; partida `80000001` y kardex `70001`. Los números
mantienen la longitud de sus ejemplos anteriores. Las cantidades mantienen
el patrón `S/ 12,345.67`. Los sustitutos nominales y sus erratas conservan
las relaciones de igualdad, ausencia, flexión y corrección que prueban los tests.

Validación T005 en Python 3.13.9, con un entorno temporal y las versiones ya
fijadas `rapidfuzz==3.14.5` y `spylls==0.1.7`, sin modificar requisitos:

| Comprobación | Resultado |
|---|---|
| `python test_ortografia.py` | PASS: 11 errores, 11 palabras correctas y tratamiento de apellidos ficticios. |
| `python test_revisor_llm.py` | PASS: 10 casos, 4 aceptados y 6 descartados; sin llamadas a modelos. |
| Casos léxicos autónomos | PASS: acentos y flexión/errata conservados. |
| `catalogo` y regex con textos ficticios | PASS: DNI rotulado, CUI de imagen, ambas formas de partida y montos con separador de miles y dos decimales. |
| AST de los 13 archivos Python y comparación de aserciones | Sintaxis válida; 34 aserciones conservadas en los cinco tests. AST ejecutable de verificador y léxico sin cambios. |
| Revisión de originales en árbol y contenido añadido | Sin coincidencias de los identificadores y nombres retirados; referencias nuevas neutras. Las líneas eliminadas permanecen en el historial privado, no se duplican en evidencia. |
| Revisión local de patrones de secretos | Sin coincidencias detectadas en los 72 archivos. Es una comprobación limitada por patrones, separada de la revisión de datos personales; gitleaks todavía no está instalado y se incorpora en etapas posteriores. |
| `git check-ignore --stdin` | PASS para 17 rutas ficticias de expedientes, secretos y artefactos; `.env.example` sigue versionable. |
| `ruff check .` | Cinco hallazgos preexistentes (E401/E741), comprobados contra la revisión inicial sin hallazgos nuevos; corrección reservada a etapa 4. |
| `git diff --check` | PASS. |

T005 aprobado para saneamiento. La suite documental completa no se declara
aprobada: faltan los fixtures sintéticos de etapa 2 y la adaptación de
`textutil` a Linux de etapa 3. No se midió cobertura ni se declaró CI verde.
T006 registra estos cambios en el commit local `chore: sanitize repository data`;
no incluye push ni integración. El historial no se reescribe y publicar el
repositorio exige limpiarlo en una fase aparte. La etapa 2 no se inicia aquí.

## Prerrequisitos

Para etapa 2 basta Python 3.13, los dos archivos de requisitos y los recursos
OCR/diccionario indicados a continuación. LibreOffice se integra en etapa 3;
Ruff y pip-audit se validan en etapa 4; gitleaks y controles remotos pertenecen a etapas posteriores.

- Clon limpio privado, Python 3.13, Git y LibreOffice (`soffice` en PATH) en Linux; gitleaks fijado y verificado según documentación de implementación.
- Recursos OCR y diccionario es_PE aprovisionados con los orígenes/versiones documentados. Solo fixtures ficticios; ningún expediente privado en el clon.
- Antes de conectar Sonar: revisión de saneamiento del contenido y nombres, configuración CI presente, análisis automático desactivado, proyecto Cloud privado. GitHub Pro/Team/Enterprise y Sonar Team/Enterprise para las capacidades elegidas; verificar disponibilidad, no contratar automáticamente.
- Variables públicas de proyecto/organización y `SONAR_TOKEN` aprovisionados por el responsable en almacenes de secretos; nunca pegarlos en comandos o documentos.
- `ERP_NOMBRE` (F28, opcional): nombre de la notaría que muestran la barra lateral, el ingreso y los títulos; el sello usa las iniciales de sus dos primeras palabras. Por defecto «ERP Notarial». Se configura solo en el entorno del servidor; el nombre real nunca se escribe en el repositorio.
- `ERP_LOGO` (F29, opcional): URL del logo de la notaría (PNG o JPEG) para la barra lateral, el ingreso y el reporte Word. Copie el logo a `static/marca/logo.png` (no se versiona: `*.png` está en `.gitignore`) y defina `ERP_LOGO=/static/marca/logo.png`. Sin valor se muestra el sello con las iniciales.

## Aprovisionamiento reproducible de pruebas · T012

```bash
python3.13 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt -r requirements-dev.txt
```

El generador usa solo stdlib, PyMuPDF y openpyxl, ya presentes en los requisitos
productivos. No necesita python-docx, reportlab, fuentes externas ni documentos
de clientes. Genera el DOCX como ZIP/XML, la imagen con las fuentes incorporadas
de PyMuPDF y el XLSX con openpyxl. Orden, fechas, permisos ZIP y metadatos son
fijos; los PDF no incorporan identificadores aleatorios.

El OCR predeterminado usa el detector `ch_PP-OCRv5_mobile_det.onnx` de
`https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.4.0/onnx/PP-OCRv5/det/ch_PP-OCRv5_mobile_det.onnx`
(SHA-256 `4d97c44a20d30a81aad087d6a396b08f786c4635742afc391f6621f5c6ae78ae`)
y el reconocedor `latin_PP-OCRv5_rec_mobile_infer.onnx` de
`https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.4.0/onnx/PP-OCRv5/rec/latin_PP-OCRv5_rec_mobile_infer.onnx`
(SHA-256 `b20bd37c168a570f583afbc8cd7925603890efbcdc000a59e22c269d160b5f5a`).
Ambos se descargan y verifican en el paso `Verify public test resources` del CI;
la ejecución del ERP solo usa los archivos locales. El diccionario es_PE se fija al commit
`32b006a2c22a4ac7e8ed3f03346f7b3d85a970a4` de LibreOffice/dictionaries.
Antes de los tests, ejecutar el paso `Verify public test resources` de
`.github/workflows/ci.yml`, que aprovisiona únicamente esos recursos públicos y
comprueba los SHA-256 de ambos modelos y del diccionario. Después:

```bash
python scripts/generar_fixtures.py
python -m pytest --cov --cov-report=term --cov-report=xml:coverage.xml
```

No se descargan expedientes en pruebas. Si falta un recurso, se aprovisiona antes
de ejecutar la suite. Los 11 documentos ficticios se regeneran y permanecen
ignorados; no se añaden a Git a la fuerza. La conversión a `.doc` sigue dentro
del test legacy y usa LibreOffice desde T017 (ver etapa 3).

## Checkpoint ejecutado · Etapa 2 (T007–T014)

Entorno: Python 3.13.9, pytest 8.4.2, pytest-cov 7.0.0 y requisitos productivos
sin cambios. Antes de crear los fixtures, las pruebas de cuadro de texto,
verificación y léxico fallaron por archivos ausentes; después se aprobaron.

| Casos conservados | Evidencia |
|---|---|
| Imagen OCR, filtro de sello inclinado, lectura repetida/caché y PDF escaneado | Imagen ficticia con DNI, rótulos y sello; catálogo de cuatro personas y lectura de DNI correcta. El PDF contiene imagen y cero texto embebido. |
| `.doc` OLE, texto convertido y lectura `.rtf` | Aserciones conservadas en `test_legacy`; único fallo Linux pendiente de etapa 3, sin skip ni xfail. |
| XLSX y nota de cuadro de texto | Filas conservadas; nota dentro de `w:txbxContent` en Choice y Fallback, dos copias en XML y una en texto extraído. |
| Catálogo, borrador observado, resultado sin falsos positivos y diagnóstico | DNI/partida/cuatro nombres, al menos seis observaciones, resultado vacío y rechazo de plantilla ajena, también mezclada con fuentes válidas. La plantilla de diagnóstico usa DOCX; el caso de lectura DOC permanece en el test legacy. |
| Léxico | Seis correcciones, corpus sin errores, tres errores de minuta, acento grave y flexión frente a errata. |
| Ortografía | Once errores, once correctas, apellidos ficticios con/sin extra y correcciones exactas de tilde. |
| Filtro determinista | Diez casos, cuatro aceptados, seis descartados y respaldo de fuentes; sin invocar modelos. |
| Casos adicionales | PDF con texto, tabla DOCX, tabulador sin XML residual, regeneración binaria idéntica y cinco escenarios de selección/privacidad. |

Resultados T013:

- `python -m pytest --collect-only -q`: 15 pruebas seleccionadas de 16;
  la medición `local_reference` está deseleccionada por defecto.
- Suite completa con cobertura: **14 aprobadas, 1 fallo conocido (`textutil`),
  1 deseleccionada**. Una copia limpia del árbol, sin fixtures previos, reproduce
  ese resultado después de generar, también con `CI=true`.
- Regeneración: los SHA-256 de los 11 fixtures son idénticos entre ejecuciones.
- Cobertura: XML parseable, rutas relativas, 643 líneas productivas y 338
  cubiertas (52,57 %). Incluye explícitamente los ocho módulos productivos,
  también las interfaces y benchmark no importados (0 %); tests y generador no
  incrementan el denominador. No se impone un 80 % global. Si se solicita
  cobertura sin XML válido/productivo, la sesión no aprueba.
- Selección local: exclusión predeterminada y al quitar `addopts`; rechazo en CI
  aunque se seleccione el marker; error saneado ante ruta ausente, incluso con
  `--showlocals --tb=long -s`. El recorrido completo local se probó con una copia
  temporal exclusivamente sintética: ocho observaciones, cero falsos positivos
  y cinco repeticiones iguales. No se abrieron expedientes reales.
- La medición privada requiere exactamente `-m local_reference`, directorio
  externo y archivos presentes. Descarta capturas, sanea errores y elimina
  su caché OCR temporal incluso al fallar.

T013 aprobado con la única limitación legacy prevista. T014 registra el commit
local `test: add synthetic fixtures and pytest`; no hay push ni avance a etapa 3.

## Etapa 3: T015–T019 ejecutadas (T018 con medición local del usuario)

LibreOffice en Linux: paquete de la distribución (`apt install libreoffice-writer`
o el paquete correspondiente), ejecutable `soffice` en PATH. Probado con LibreOffice 26.2,
Python 3.13.

- Tests primero: `test_legacy` y `test_legacy_sin_libreoffice` fallaron antes del
  cambio. Único caller de `_legacy`: `leer` en `extraer.py`.
- `_legacy` usa `textutil` en macOS (sin cambios) y `soffice --headless` en el
  resto: argumentos sin shell, timeout de 120 s, directorio temporal y perfil
  aislado por conversión. Ejecutable ausente, fallo o sin salida → `ValueError`
  sin stderr, contenido ni rutas.
- `test_legacy` crea el `.doc` OLE desde `minuta.rtf` con el mismo conversor;
  comprueba lectura `.doc`/`.rtf` y que no quedan temporales.
- Suite completa con cobertura en Linux: **16 aprobadas, 1 deseleccionada**, sin
  fallos; dos ejecuciones consecutivas y regeneración de fixtures sin cambios.
- T018: medición `local_reference` ejecutada por el usuario el 2026-09-18 en su
  máquina, con `EXPEDIENTES_REFERENCIA_DIR` fuera del repositorio, sobre el
  código final de `extraer.py` (`745ee94`):
  **1 passed** (8 observaciones en el borrador, salida idéntica en 5 corridas,
  0 en la escritura correcta). Sin regresión por el cambio de `extraer.py`; el
  test no emite datos del expediente.

## Checkpoint ejecutado · Etapa 4 (T020–T025)

Entorno nuevo `.venv/t024`, Python 3.13.9, instalado únicamente desde ambos
archivos de requisitos; recursos OCR/diccionario verificados con los hashes de
T012. Herramientas fijadas: Ruff 0.16.8, pip-audit 2.10.1, pre-commit 4.6.2,
pytest 9.0.3 y pytest-cov 7.0.0. Pre-commit queda instalado; su configuración y
activación pertenecen a etapa 5.

Cambios de versiones: Pillow 11.0.0 → 12.3.0 y pytest 8.4.2 → 9.0.3.
La auditoría inicial emitió 35 filas (18 IDs únicos) en esos dos paquetes;
la final no encuentra vulnerabilidades, sin IDs exceptuados. Se corrigieron
los IDs de Pillow PYSEC-2026-{165,2249,2250,2252,2253,2254,2255,2256,2257,
2874,3451,3453,3454,3493,3494,3495,3496} y de pytest PYSEC-2026-1845.
Las restantes versiones directas no cambiaron; `pip check` confirma compatibilidad.
Versiones consultadas en [PyPI](https://pypi.org/) y comprobadas por instalación
real en Python 3.13 y auditoría estricta de las dependencias transitivas.

Ruff: 13 hallazgos iniciales, 7 corregidos y 6 justificados. Se separaron dos
imports E401 y renombraron tres variables E741; se aplicó formato a los 18
archivos Python propios. S324: SHA-1 solo identifica la caché, se declara
`usedforsecurity=False` y se conserva la clave anterior. S607: macOS usa
`/usr/bin/textutil`, evitando buscar el binario en PATH; el nuevo test ficticio
falló antes del cambio y pasó después, conservando argumentos y tabuladores.
No se alteraron reglas de negocio ni se ejecutaron modelos o expedientes reales.

Política para el PR: S101 permitido únicamente en `test_*.py` y `tests/**` por
per-file-ignores, porque pytest usa asserts. Las demás excepciones S requieren
`noqa` individual con código exacto y motivo, listadas en el PR. El coordinador
aprobó esta precisión durante T021 y se sincronizó la frase en spec, plan y
contrato CI; no hay exclusiones globales ni por archivo de otras reglas.
Copiar al PR las seis excepciones revisadas:

| Ubicación | Regla | Justificación individual |
|---|---|---|
| `extraer.py` · `_soffice` | S603 | LibreOffice: conversor configurado por código, argumentos en lista sin shell, perfil temporal propio; no se interpreta una cadena de comandos del documento. |
| `extraer.py` · `_legacy` | S603 | textutil: ejecutable absoluto fijo, opciones fijas y ruta como argumento, sin shell. |
| `ortografia.py` · `_descargar` | S310 | Descarga de diccionario desde URL HTTPS fija en código; solo concatena `.aff`/`.dic` internas, no una URL suministrada por documentos. |
| `revisor_llm.py` · `consultar` | S310 | Request construido con esquema HTTPS y host fijos; modelo va en la ruta, no cambia el esquema; no se invocó la red de modelos durante las pruebas. |
| `tests/conftest.py` · `pytest_sessionfinish` | S314 | XML local de confianza generado por coverage en la misma ejecución; no es XML de documentos subidos. |
| `tests/test_seleccion_local.py` · `test_seleccion_privada` | S603 | Intérprete propio y argumentos de pytest fijados por el test, entorno controlado y sin shell. |

No se añadieron dependencias para estas revisiones ni se cambiaron APIs para
eludir el detector. Las excepciones deben revisarse si cambia la procedencia de
argumentos, URLs o XML; no autorizan procesar entradas arbitrarias sin validación.

Con el entorno nuevo activado, resultados del checkpoint T024:

| Comando / comprobación | Resultado |
|---|---|
| `python -m pip install -r requirements.txt -r requirements-dev.txt` | PASS en entorno nuevo, sin dependencias previas. |
| Aprovisionamiento T012 | PASS: SHA-256 de tres modelos OCR y dos archivos del diccionario. |
| `python scripts/generar_fixtures.py` | PASS: fixtures exclusivamente ficticios. |
| `ruff check .` | PASS: cero hallazgos pendientes. |
| `ruff format --check .` | PASS: 56 archivos examinados, sin reformatear. |
| `python -m pytest --cov --cov-report=term --cov-report=xml:coverage.xml` | PASS: 17 passed, 1 deselected; incluye los 16 casos previos y el test macOS. |
| `coverage.xml` | XML válido, ocho módulos productivos, rutas relativas, 665 líneas válidas / 366 cubiertas (55,04 %); sin imponer umbral global. |
| `pip-audit --strict -r requirements.txt -r requirements-dev.txt` | PASS: No known vulnerabilities found; cero excepciones. |
| `python -m pip check` | PASS: No broken requirements found. |
| Muestras ficticias por stdin de Ruff | S101 detectada fuera de tests; S301 detectada dentro de tests; assert permitido en tests. No se conservaron muestras. |
| Revisión del diff y `git diff --check` | PASS: cambios de formato, correcciones descritas y documentación; sin nuevos datos reales ni secretos. |

T024 aprobado. T025 registra el commit local `chore: pass lint and dependency audit`.
No se inicia etapa 5, no hay push, PR, cambios de CI ni activación de Sonar.
T019 está completada por `2be5a48`, «Finalizar etapa 3» (mensaje distinto al
previsto); T018 completada después con la medición local del usuario (ver etapa 3).

Deuda fuera de alcance: revisor_llm.py envía la API key en la query (?key=); usar cabecera x-goog-api-key si la capa experimental se reactiva.

## Checkpoint local · Etapa 5 (T026–T032)

PR 1 queda preparado con un único workflow para `pull_request` y push a `main`,
sin filtros de rutas: `lint`, `tests`, `dependencies` y `secrets`. Todos usan
`ubuntu-24.04`, timeout de 30 minutos y permisos `contents: read`; checkout no
persiste credenciales. No existen jobs `sonar`, `ci-required` ni evento
`pull_request_target`. Solo `coverage.xml` se publica, por ejecución/intento y
con retención de 7 días; los fixtures y el workspace no son artefactos.

Acciones fijadas a SHA completo y verificadas contra sus tags remotos:

| Acción | Versión | SHA |
|---|---|---|
| `actions/checkout` | v7.0.1 | `3d3c42e5aac5ba805825da76410c181273ba90b1` |
| `actions/setup-python` | v7.0.0 | `5fda3b95a4ea91299a34e894583c3862153e4b97` |
| `actions/upload-artifact` | v7.0.1 | `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a` |

Las tres acciones usan Node 24 y conservan las entradas empleadas. El escáner
CI descarga el binario oficial Gitleaks 8.28.0 para Linux x64 y verifica el
SHA-256 publicado `a65b5253807a68ac0cafa4414031fd740aeb55f54fb7e55f386acb52e6a840eb`
antes de extraerlo. Escanea con redacción el árbol y el rango exacto base..head;
en el primer push limita el escaneo a HEAD. `sonar-project.properties` solo
delimita fuentes, tests y `coverage.xml`: no contiene token, organización o
proyecto ni activa análisis.

Pre-commit se instala y activa así:

```bash
python -m pre_commit install
python -m pre_commit run --all-files
```

La configuración fija Ruff 0.16.8 y Gitleaks 8.28.0 por SHA. El checkpoint
local aprobó los tres hooks sobre todo el árbol. En una copia temporal externa,
muestras exclusivamente ficticias confirmaron por separado el bloqueo S307,
el formato no aplicado y un secreto de prueba; Gitleaks mostró únicamente el
valor redactado. Tras retirar las muestras, los tres hooks volvieron a verde.

Dependabot contiene exactamente dos revisiones semanales (`pip` y
`github-actions`) desde la raíz, sin auto-merge. La validación local final dio:

| Comprobación | Resultado |
|---|---|
| YAML y workflow | PASS: tres YAML parseables; Actionlint 1.7.12 sin hallazgos. |
| Tags e inputs de acciones | PASS: SHA verificados con `git ls-remote --tags`; runtime Node 24 e inputs usados presentes en cada `action.yml`. |
| Binario Gitleaks 8.28.0 | PASS: tar oficial Linux x64 coincide con el checksum publicado; un checksum ficticio incorrecto falla. |
| `python -m ruff check .` | PASS. |
| `python -m ruff format --check .` | PASS: 56 archivos ya formateados. |
| Generador + pytest explícitamente sin `local_reference` | PASS: 17 aprobadas, 1 deseleccionada; el paso CI adicional confirma clases en `coverage.xml`, con rutas relativas, 665 líneas válidas / 366 cubiertas (55,04 %). |
| `python -m pip_audit --strict -r requirements.txt -r requirements-dev.txt` | PASS: sin vulnerabilidades conocidas. |
| `python -m pre_commit run --all-files` | PASS: Ruff check, Ruff format y Gitleaks. |
| Gitleaks sobre copia limpia y rango `9ca2cc9..HEAD` | PASS: árbol y commits de etapa sin hallazgos; salida redactada. |
| Revisión de configuración/diff | PASS: sin datos reales, secretos, dependencias Python nuevas, jobs posteriores ni artefactos privados. |

En ese checkpoint local, los cuatro checks remotos, el push y T033–T036 todavía
estaban pendientes; su cierre posterior queda registrado a continuación.

## Cierre remoto de PR 1 · T033–T036

El commit de cierre T033 `9378343` se publicó mediante el
[PR #8](https://github.com/Angello5/confrontador-notarial/pull/8). Su revisión
final `9777e52` se integró en `main` como `4cb625e`, sin reescritura de historia.
La [ejecución 35315252141](https://github.com/Angello5/confrontador-notarial/actions/runs/35315252141)
de `main` terminó con `lint`, `tests`, `dependencies` y `secrets` en `success`.
El commit `875a57b`, que registra la medición T018, es posterior a esa revisión y
se incorpora con PR 2.

Incidente registrado: Automatic Analysis permaneció activo en SonarQube Cloud
desde el 2026-09-17 mientras `main` todavía contenía datos personales reales en
tests. El 2026-09-18 se desactivó, se eliminó el proyecto y se recreó privado con
Automatic Analysis desactivado. Este registro no reproduce datos afectados ni
valores de credenciales.

## Implementación local · T039–T041

La constitución v1.4.0 cubre el uso de SonarQube Cloud privado, el análisis desde
CI, Sonar way y la excepción única de arranque ya consumida por PR 1. El roadmap
conserva F1 en curso.

El job `sonar` descarga `coverage.xml` del mismo `run_id` y `run_attempt`, usa
checkout completo sin credenciales persistentes y ejecuta únicamente la acción
oficial de análisis. `SONAR_TOKEN` solo se expone al paso del escáner y su
ausencia falla antes del análisis. La acción
`SonarSource/sonarqube-scan-action` v8.2.2 quedó fijada a
`ba9859eae8dd6bd29e412f25ddbbef3d032000f4`, verificado con
`git ls-remote --tags`; el gate espera hasta 300 segundos. `ci-required` agrega
exactamente los cinco controles y solo acepta cinco resultados `success`.
El responsable confirmó que el secreto está aprovisionado en GitHub Actions y
lo añadirá al almacén de Dependabot; su valor no se inspeccionó ni se registró.
Actionlint 1.7.12 y `pre-commit run --all-files` aprobaron esta configuración.

## Validación local sintética

Desde la raíz del repositorio, después de implementar:

```bash
python3.13 -m venv .venv
. .venv/bin/activate
python -m pip install --require-hashes --only-binary :all: --no-binary antlr4-python3-runtime -r requirements.txt -r requirements-dev.txt
python scripts/generar_fixtures.py
python -m ruff check .
python -m ruff format --check .
python -m pytest -m 'not local_reference' --cov --cov-report=term --cov-report=xml:coverage.xml
python -m pip_audit --strict -r requirements.txt -r requirements-dev.txt
```

Los archivos `requirements.in` y `requirements-dev.in` son las fuentes que
actualiza Dependabot; los `.txt` bloquean también las dependencias transitivas.
Para regenerarlos con Python 3.13 y `pip-tools==7.6.1`:

```bash
python -m piptools compile --generate-hashes --output-file=requirements.txt requirements.in
python -m piptools compile --generate-hashes --allow-unsafe --output-file=requirements-dev.txt requirements-dev.in
```

La instalación conserva `--only-binary :all:` y una excepción individual:
`antlr4-python3-runtime==4.9.3`, dependencia transitiva fijada de `omegaconf`,
solo publica un sdist para esa versión. El hash del lock protege el sdist, pero
su aislamiento de compilación instala `setuptools>=40.8.0` sin versión fija ni
hash y ejecuta con él el código de construcción. Es un riesgo residual aceptado
y registrado en `docs/deuda-f3.md`; se revisará una instalación en dos pasos con
`setuptools` bloqueado y `--no-build-isolation`. El CI no cambia en F1.

En etapa 5, una vez configurados gitleaks y `.pre-commit-config.yaml`, añadir:

```bash
# En una copia limpia del árbol versionable, sin el entorno virtual local:
gitleaks dir --redact .
gitleaks git --redact --log-opts="$BASE..$HEAD"
python -m pre_commit install
python -m pre_commit run --all-files
```

Esperado: pruebas recolectadas y aprobadas; XML válido con líneas productivas; código existente en verde, sin exclusiones globales. Repetir generación y pruebas conserva resultados. Los expedientes reales nunca son necesarios. El escaneo de directorio complementa, no sustituye, el escaneo de commits de CI.

## Medición local con expedientes externos

La ruta se configura localmente mediante `EXPEDIENTES_REFERENCIA_DIR`, fuera del repositorio, sin imprimirla. El test lee y mide dentro de su cuerpo y solo devuelve resumen no identificable.

Ese directorio externo debe contener `cliente/`, `observado.docx` y
`correcto.docx`, correspondientes al expediente de referencia con baseline
ocho observaciones y cero falsos positivos. Los nombres locales neutros no se
versionan; el test nunca lee datos privados al importar o recolectar. Cambiar
esa baseline requiere una medición y decisión expresa, no ajustar el test para
obtener verde.

```bash
python -m pytest -o addopts= -m local_reference --tb=no -q
```

## Análisis inicial y resolución T038

El usuario ejecutó el análisis inicial de SonarCloud el 2026-09-18 sobre
`main` `4cb625e` (`master` en SonarCloud), con cobertura del mismo análisis. El
inventario resultó en 13 vulnerabilidades, 7 bugs, 10 code smells y 0 Security
Hotspots.

| Hallazgos | Resolución en PR 2 |
|---|---|
| githubactions:S8541, 3 casos de instalación | Corregidos: CI instala ambos locks con `--require-hashes --only-binary :all:`. |
| githubactions:S8544, 3 casos de resolución | Corregidos: fuentes `.in` y locks `.txt` generados por pip-compile con hashes y transitivas. |
| githubactions:S6506, descarga de Gitleaks | Corregido: curl exige HTTPS y TLS 1.2. |
| pythonsecurity:S8707, 4 rutas en `extraer.py` | Corregidos en el adaptador compartido: ruta absoluta existente, archivo regular y sufijo legacy antes del subprocess. |
| pythonsecurity:S8705, `_soffice` y `_legacy` | Mitigados y justificados: CLI local, argv sin shell, ejecutable/opciones internos y ruta validada; revisar si esas opciones pasan a ser entrada no confiable. |
| python:S5779, 4 casos en `tests/conftest.py` | Corregidos con comprobaciones explícitas y `_CoberturaInvalida`. |
| python:S5779, 3 casos en `tests/test_referencia_local.py` | Corregidos con comprobaciones explícitas y `_MedicionInvalida`; la salida sigue saneada. |
| 10 code smells | Registrados individualmente en `docs/deuda-f3.md`; quedan para F3 sin bloquear F1. |

La prueba ficticia con un archivo `-ficticio.rtf` falló antes del cambio y
comprueba ahora que el subprocess recibe una ruta absoluta. Otra prueba impide
invocar el conversor para directorios o sufijos fuera de `LEGACY`. El diseño de
CLI local restante se justifica también en `docs/deuda-f3.md`; no se añadió una
exclusión ni un `noqa` de Sonar.

## Quality Gate T042

El proyecto usa el Quality Gate **Sonar way**: Security Rating A (0
vulnerabilidades nuevas), Reliability Rating A (0 bugs nuevos), 100 % de
Security Hotspots revisados, cobertura de al menos 80 %, Maintainability Rating
A y duplicación máxima de 3 % en código nuevo. El plan gratuito no permite gates
personalizados y Sonar way no evalúa duplicación ni cobertura cuando el cambio
contiene menos de 20 líneas nuevas. La
constitución v1.4.0 acepta expresamente esta limitación y exige revisar la
decisión si cambia el plan. Los code smells previos no forman parte del gate.

Esperado: ejecución únicamente tras selección expresa, resumen sin datos personales y fallo saneado si falta el directorio o los archivos requeridos. Ejecutar el mismo comando con indicador CI debe ser rechazado. Si se modificó el núcleo, comparar con baseline local sin regresión antes del merge; no subir reportes de contenido.

## PR 1 · Etapas 1–5

1. Validación previa local: tests, ruff, auditoría y secretos en verde; árbol/diff saneados.
2. Commit de etapa y push de rama privada.
3. PR 1 en borrador: verificar lint, tests, dependencies y secrets para el SHA final. No existen sonar ni ci-required aún.
4. Pasar PR 1 a listo y mergear con los cuatro checks verdes, sin bypass.
5. Verificar ejecución de los cuatro controles en main; registrar evidencia en el PR.

## Entre PRs · Conexión por el usuario

El usuario conecta SonarQube Cloud privado y realiza el primer análisis de main ya saneada, con cobertura de ese SHA y configuración preparada. No analizar commits anteriores. Verificar alcance de fuentes y metadatos antes del envío. Esperar esta acción si aún no se completó; nunca pedir secretos en chat.

## PR 2 · Etapa 6

1. Inventariar vulnerabilidades, bugs y Security Hotspots existentes; corregirlos o justificarlos individualmente por escrito. Registrar code smells existentes como deuda F3 en `docs/deuda-f3.md`, sin bloquear ni excluir código del análisis.
2. Añadir sonar y ci-required de cinco dependencias y Sonar way; la constitución v1.4.0 documenta la limitación del plan gratuito y conserva la cláusula de arranque.
3. Validación previa local y evidencias de hallazgos; commit/push; abrir PR 2.
4. Verificar cinco controles y agregado. Probar fallos individuales, omisión/cancelación, ausencia de cobertura/credenciales, umbrales, cambios pequeños y sin código productivo nuevo. Solo material ficticio; retirar pruebas antes de merge.
5. Verificar PR de Dependabot y documentación, sin auto-merge. No ensayo de forks ni escenario independiente de SHA obsoleto; mantener protección de rama actualizada y prohibición de pull_request_target.
6. Verificar protección de seis checks, PR obligatorio, cero reviews requeridas, sin bypass/force push. Si cambia código/configuración, nuevo commit/push y checks del SHA final.
7. Mergear PR 2 con todos los checks verdes.
8. Verificar ejecución completa en main después del merge; solo entonces declarar F1 terminada. Registrar evidencia posterior en el PR, sin commits directos a main.

## Cierre de F1 · T043–T049

T043 quedó validada sobre el árbol final: Python 3.13.9, generación de
fixtures ficticios, Ruff check y formato, **21 passed, 1 deselected**, cobertura
XML válida (677 líneas productivas, 378 cubiertas), `pip-audit` sin
vulnerabilidades y los tres hooks de pre-commit en verde. La resolución de
hallazgos y la deuda F3 están registradas arriba. La medición privada T018 fue
ejecutada por el usuario sobre `745ee94`: **1 passed**, sin publicar datos ni
rutas. El diff de cierre solo contiene documentación.

T044–T045: los commits de etapa `a785149`, `3c003cc` y `745ee94` se publicaron
sin reescribir historia. El [PR #14](https://github.com/Angello5/confrontador-notarial/pull/14),
sobre `745ee94`, aprobó `lint`, `tests`, `dependencies`, `secrets`, `sonar`
(Quality Gate OK) y `ci-required` en el
[run 35360132624](https://github.com/Angello5/confrontador-notarial/actions/runs/35360132624).

Casos negativos observados en remoto:

- En el intento 1 del run de `main` `35360401832`, Sonar devolvió **Not
  computed** porque el proyecto recreado no tenía definida la referencia de
  código nuevo; `sonar` y `ci-required` fallaron de forma segura.
- Al usar **Re-run failed jobs**, `sonar` no encontró la cobertura del mismo
  `run_attempt` y volvió a fallar. En este workflow se debe usar siempre
  **Re-run all jobs**.
- El PR de Dependabot #11 hizo fallar `tests` por el cambio de modelos y hashes
  de RapidOCR; `sonar` quedó omitido y `ci-required` falló, bloqueando el PR.

No se ensayaron en remoto, de manera aislada, fallos de `lint`, `dependencies`
o `secrets`; cancelación manual; ausencia del secreto; ni cada umbral del gate
(bugs, vulnerabilidades, hotspots y cobertura). Tampoco se ensayaron
separadamente cambios de menos de 20 líneas productivas o sin código productivo
nuevo. El contrato no exige ensayos de forks ni de SHA obsoleto independiente,
y no se realizaron.

T046 se verificó en solo lectura con `gh pr view` y `gh pr checks`. Todos los PR
están abiertos, sin auto-merge, y recibieron los mismos seis controles. El
secreto de Dependabot existe y permitió ejecutar Sonar en los PR aprobados, sin
inspeccionar su valor; en #11 `sonar` se omitió por el fallo previo de `tests`.

| PR | Actualización | Estado |
|---|---|---|
| [#9](https://github.com/Angello5/confrontador-notarial/pull/9) | Streamlit 1.63.0 | Seis checks en verde; mergeable. |
| [#10](https://github.com/Angello5/confrontador-notarial/pull/10) | onnxruntime 1.30.0 | Seis checks en verde; mergeable. |
| [#11](https://github.com/Angello5/confrontador-notarial/pull/11) | RapidOCR 3.9.2 | Bloqueado: `tests` falla por modelos/hashes esperados, `sonar` se omite y `ci-required` falla. |
| [#12](https://github.com/Angello5/confrontador-notarial/pull/12) | pytest-cov 7.1.0 | Seis checks en verde; mergeable. |
| [#13](https://github.com/Angello5/confrontador-notarial/pull/13) | pandas 3.0.5 | Seis checks en verde; mergeable. |

T047: el ruleset
[`23667199`](https://github.com/Angello5/confrontador-notarial/rules/23667199)
está activo sobre la rama por defecto. Exige PR con cero aprobaciones,
`lint`, `tests`, `sonar`, `dependencies`, `secrets` y `ci-required` publicados
por GitHub Actions, rama actualizada (`strict`), sin bypass, borrado ni force
push.

T048–T049: el PR #14 se integró en `main` como `45ce0b6`. El
[run 35360401832](https://github.com/Angello5/confrontador-notarial/actions/runs/35360401832),
intento 3, terminó con los seis jobs en `success` después de definir en
SonarCloud el código nuevo como **Previous version**; el proyecto recreado no
tenía esa definición y por eso el gate inicial aparecía como **Not computed**.
F1 queda terminada.

Nota operativa: al publicar una versión del ERP, incrementar
`sonar.projectVersion` para reiniciar la línea base de código nuevo.
