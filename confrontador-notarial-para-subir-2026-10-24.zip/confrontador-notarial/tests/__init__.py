"""Project test configuration package."""
